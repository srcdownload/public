This sample illustrates how to use the Azure Kinect API to access both depth and color captures.

Use on the command line as follows:

    streaming_samples.exe 10 // application will sample 10 color/depth frames
