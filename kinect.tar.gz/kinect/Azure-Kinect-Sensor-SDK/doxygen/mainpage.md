# Welcome

This documentation describes the API usage for the Azure Kinect Sensor SDK.

For details about the Azure Kinect DK hardware and for more information about getting started with development please see https://azure.com/kinect.

## API Languages

The Azure Kinect Sensor SDK is primarily a C API. This documentation also covers the C++ wrapper. For the most detailed documentation of
API behavior, see the documentation for the C functions that the C++ classes wrap.
