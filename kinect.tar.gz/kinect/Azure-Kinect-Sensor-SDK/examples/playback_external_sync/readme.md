# Playback External Sync example

## Introduction

The external sync playback example shows how to open recordings generated from multiple cameras in external sync mode, and access the individual frames from each camera in a synchronized manner.

## Usage Info

       playback_external_sync.exe <master.mkv> <sub1.mkv> <sub2.mkv>...
